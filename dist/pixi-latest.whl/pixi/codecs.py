from enum import Enum


class Codecs(Enum):
    H264 = "libx264"
    H265 = "libx265"
    VP8 = "vp8"
    VP9 = "vp9"
    MPEG4 = "mpeg4"
    # MJPEG = "mjpeg" # TODO: needs to be fixed
    THEORA = "theora"
    AV1 = "av1"
