import requests
from urllib.parse import urljoin


def get_keycloak_token(base_url, client, secret, user, password):

    data = {
        "client_id": client,
        "client_secret": secret,
        "username": user,
        "password": password,
        "grant_type": "password",
        "scope": "profile"
    }

    response = requests.post(
        urljoin(base_url, "/auth/realms/safety/protocol/openid-connect/token"),
        data=data)

    if response.status_code == 200:
        token_data = response.json()
        access_token = token_data["access_token"]
        return access_token
    else:
        return None
