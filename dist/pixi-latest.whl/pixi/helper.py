import os
from urllib.parse import urlparse


def is_file_path_or_url(path):
    # Verifica se a string é um caminho de arquivo válido
    try:
        if os.path.exists(path):
            return "Arquivo"
    except:
        pass

    try:
        parsed_url = urlparse(path)
        if parsed_url.scheme in ("http", "https", "rtsp"):
            return "URL"
    except:
        pass

    return "Não reconhecido"
