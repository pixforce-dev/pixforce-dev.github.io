class StreamOpenException(Exception):
    pass
