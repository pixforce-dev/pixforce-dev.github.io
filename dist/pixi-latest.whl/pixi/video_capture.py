from collections import deque, Counter
from typing import Optional, Tuple, List
from time import sleep
from pixi.get_token import get_keycloak_token
import numpy as np
from threading import Thread
import av
import cv2
from threading import Lock
from fractions import Fraction
import pixi.pixi_exceptions as pixi_exceptions


av.logging.set_level(av.logging.PANIC)


class VideoCapture:
    def __init__(self, path,
                 keycloak_base_url=None,
                 keycloak_client=None,
                 keycloak_secret=None,
                 keycloak_user=None,
                 keycloak_password=None,
                 undersample=1,
                 image_format="bgr24",
                 packet_fifo_sz=1000,
                 frame_list_sz=1000,
                 options={}):
        self._path = path
        self._keycloak_base_url = keycloak_base_url
        self._keycloak_client = keycloak_client
        self._keycloak_secret = keycloak_secret
        self._keycloak_user = keycloak_user
        self._keycloak_password = keycloak_password
        self._width = 0
        self._height = 0
        self._last_frame = None
        self._enable_show = False
        self._container = None
        self._fps_fifo_sz = frame_list_sz  # has the same size as frame_list
        self._fps_fifo = deque(maxlen=self._fps_fifo_sz)
        self._packet_fifo_sz = packet_fifo_sz
        self._packet_fifo = deque(maxlen=self._packet_fifo_sz)
        self._frame_list_sz = frame_list_sz
        self._frame_list = deque(maxlen=self._frame_list_sz)
        self._stop = False
        self._decoder_thread = None
        if undersample < 1:
            raise ValueError("Undersample must be greater than 1")
        self._undersample = undersample
        self._new_packet_callback = None
        self._start_time = 0
        self._last_valid_dts = 0
        self._is_file = False
        self._undersample_pointer = 0
        self._eof = False
        self._list_lock = Lock()
        self.image_format = image_format
        self._actual_frame = 0
        self._null_packet_counter = 0
        self._options = {"options": options}
        self._rotation = 0.0

    @property
    def actual_frame(self):
        """
        Returns the actual estimated frame number
        """
        return self._actual_frame

    @property
    def path(self):
        """
        Returns the path of the video file or url
        """
        return self._path

    @property
    def fps(self) -> Optional[Fraction]:
        """Returns the guessed rate of the video from the
        underlying container"""
        if self.main_stream is None:
            return None
        return self.main_stream.guessed_rate

    @property
    def fps_average(self) -> Optional[Fraction]:
        """Returns the average rate of the video from the
        underlying container"""
        if self.main_stream is None:
            return None
        return self.main_stream.average_rate

    @property
    def fps_calculated(self) -> int:
        """Returns the calculated rate of the video from the pixi buffer.
        If there are not enough frames in the buffer, returns 0"""
        try:
            fps = Counter(self._fps_fifo).most_common(1)[0][1]
            if (2*fps) >= len(self._fps_fifo):
                return 0
            return fps
        except Exception as e:
            print("Error in fps_calculated:", e)
            return 0

    @property
    def encoding(self):
        """
        Returns the encoding of the video
        """
        try:
            return self.main_stream.codec_context.codec.name
        except Exception as e:
            print("Error in encoding:", e)
            return ""

    @property
    def width(self):
        """Width of the video in pixels"""
        return self._width

    @property
    def height(self):
        """Height of the video in pixels"""
        return self._height

    @property
    def enable_show(self):
        """Enable or disable the show method. If enabled, the frames will be shown in a window.
        Not supported on MacOS."""
        return self._enable_show

    @enable_show.setter
    def enable_show(self, value):
        self._enable_show = value
        if value:
            self._show_thread = Thread(target=self._run_show)
            self._show_thread.start()

    @property
    def undersample(self):
        """Undersample factor. The decoder will skip n-1 frames for each frame read"""
        return self._undersample

    @undersample.setter
    def undersample(self, value):
        self._undersample = value

    @property
    def is_file(self):
        """Returns True if the video is a file, False if it's a URL"""
        return self._is_file

    @property
    def eof(self):
        """Returns True if the end of the video file was reached"""
        with self._list_lock:
            if len(self._frame_list) == 0 and self._eof:
                return True
            return False

    @property
    def time_base(self) -> Optional[Fraction]:
        """Timebase of video in fraction of seconds"""
        try:
            if self.main_stream is None:
                return None
            return self.main_stream.time_base
        except Exception as e:
            print("Error in time_base:", e)
            return None

    @property
    def start_time_tb(self) -> Optional[int]:
        """Start time of video in timebase units"""
        try:
            if self.main_stream is None:
                return None
            return self.main_stream.start_time
        except Exception as e:
            print("Error in start_time_tb:", e)
            return None

    @property
    def total_frames(self) -> int:
        """Total number of frames in the video
        Returns a rough estimation if the video doesn't have this info"""
        try:
            if self.main_stream is None:
                return 0
            _fps = self.fps
            _duration_secs = self.duration_secs
            _start_time_tb = self.start_time_tb
            if _fps is None or _duration_secs == 0 or _start_time_tb is None:
                return 0
            total_frames = self.main_stream.frames or \
                int(_fps * (_duration_secs - _start_time_tb))
        except Exception as e:
            print("Error in total_frames:", e)
            total_frames = 0
        return total_frames

    @property
    def duration_secs(self) -> float:
        """Duration of video in seconds"""
        try:
            if self.main_stream is None:
                return 0.0
            _time_base = self.time_base
            _duration = self.main_stream.duration
            if _time_base is None or _duration is None:
                return 0
            return float(_duration * _time_base)
        except Exception as e:
            print("Error in duration_secs:", e)
            return 0

    @property
    def duration_tb(self) -> Optional[int]:
        """Duration of video in timebase units"""
        try:
            if self.main_stream is None:
                return None
            return self.main_stream.duration
        except Exception as e:
            print("Error in duration_tb:", e)
            return 0

    @property
    def buffer_size(self) -> int:
        """Returns the size of the frame list buffer"""
        with self._list_lock:
            return len(self._frame_list)

    @property
    def main_stream(self) -> Optional[av.stream.Stream]:
        """Returns the main video stream"""
        if self._container is None:
            return None
        return self._container.streams.video[0]

    @property
    def rotation(self) -> float:
        """Returns the rotation angle of the video"""
        return self._rotation

    def stop(self) -> None:
        """Stop the video capture and close the window."""
        self._stop = True

    def _get_path(self) -> str:
        """Returns the path of the video file or url with the token appended in the case Keycloak is used."""
        if self._keycloak_base_url is not None:
            token = get_keycloak_token(
                self._keycloak_base_url,
                self._keycloak_client,
                self._keycloak_secret,
                self._keycloak_user,
                self._keycloak_password
            )
            return f"{self._path}?token={token}"
        else:
            if self._path.startswith("rtsp://"):
                return self._path
            self._is_file = True
            return self._path

    def _rotate_frame(self, frame: np.ndarray, angle: float) -> np.ndarray:
        """Rotate frame by angle degrees. Supported angles
        are 0, 90, 180, 270, -90, -180.
        Args:
            frame: np.ndarray
            angle: int
        Returns:
            np.ndarray
        Raises:
            ValueError: Invalid rotation angle"""
        if angle == 0:
            return frame
        if angle == 90:
            return np.rot90(frame)
        elif angle == 180 or angle == -180:
            return np.flip(frame, 0)
        elif angle == 270 or angle == -90:
            return np.rot90(frame, 3)
        else:
            raise ValueError("Invalid rotation angle")

    def show(self, frame: Optional[np.ndarray] = None, wait=5) -> None:
        """
        Show the frame in a window for a given time in microseconds.
        Use 0 to wait indefinitely until a key is pressed.
        Args:
            frame: np.ndarray
                The frame to show. If None, shows the last frame.
        """
        if wait < 0:
            raise ValueError("Wait time must be greater than or equal to 0")

        _frame = None
        if frame is not None:
            _frame = frame
        else:
            _frame = self._last_frame
        cv2.imshow("Image", _frame)
        cv2.waitKey(wait)

    def _run_show(self) -> None:
        """
        Show the frames in a window. This method is called in a separate thread.
        Not supported on MacOS.
        """
        while self._enable_show and not self._stop:
            if self._last_frame is None:
                sleep(0.1)
                continue
            self.show()

    def _calculate_differences_and_average(self, lst: List[int]):
        """
        Calculate the differences between adjacent elements in a list and return the average.
        """
        differences = [b - a for a, b in zip(lst, lst[1:])]
        average = sum(differences) / \
            len(differences) if differences else 0  # Calcula a média
        return average

    def _run_decoder(self) -> None:
        """
        Decodes the video packets and stores the frames in a list.
        """
        counter = 0
        while not self._stop:
            try:
                for packet in self._container.demux(video=0):
                    # ignore flushed packets (None) and packets with invalid dts
                    if (packet.dts is None) or (
                            self._last_valid_dts >= packet.dts):

                        # count null packets to detect end of file
                        self._null_packet_counter += 1
                        if self._null_packet_counter >= 100:
                            self._null_packet_counter = 0
                            if self._is_file:
                                self._eof = True
                                self._stop = True
                                break
                        continue
                    self._null_packet_counter = 0

                    if packet.dts:
                        self._last_valid_dts = packet.dts
                    self._packet_fifo.append(packet)
                    
                    # if a new packet is available, call the new packet callback
                    if self._new_packet_callback is not None:
                        try:
                            packet1 = packet
                            if self._start_time == 0:
                                self._start_time = packet1.pts
                            # Adjust timestamps
                            packet1.pts -= self._start_time
                            packet1.dts -= self._start_time
                            self._new_packet_callback(packet1)
                        except Exception as e:
                            print("Error in new packet callback:", e)
                    else:
                        self._start_time = 0

                    # decode the packet and store the frames in the frame list
                    for frame in packet.decode():
                        with self._list_lock:
                            self._frame_list.append(frame)
                            # print("Frame time:", frame.time)
                        self._fps_fifo.append(int(frame.time))
                        if self._is_file:
                            while 1 and not self._stop:
                                # if the buffer is full, wait for it to be consumed
                                if len(self._frame_list) >= self._frame_list_sz:
                                    sleep(0.001)
                                    pass
                                else:
                                    break
                    if self._stop:
                        cv2.destroyAllWindows()
                        break
            except EOFError:
                if self._is_file:
                    self._eof = True
                    break
                else:
                    print("Token Expired... Renewing Token #", counter)
                    counter += 1
                    self._container = av.open(
                        self._get_path(), **self._options)
            except Exception as e:
                print("Error in decoder thread:", e)
                break
        self._eof = True

    def add_new_packet_callback(self, callback) -> None:
        """
        Add a callback to be called when a new packet is available.
        """
        self._new_packet_callback = callback

    def remove_new_packet_callback(self) -> None:
        """
        Remove the new packet callback.
        """
        self._new_packet_callback = None

    def open(self, **kwargs) -> bool:
        """
        Open the video file or url.
        """
        try:
            # check for options used to parameterize the underlying ffmpeg container
            options = kwargs.get("options")
            if options is not None and isinstance(options, dict):
                self._options = kwargs
            self._container = av.open(self._get_path(), **self._options)
            
            if self._container is None:
                raise pixi_exceptions.StreamOpenException("Could not open the video file or url.")
            
            try:
                # checks for frame rotation metadata
                self._rotation = self.main_stream.side_data.get('DISPLAYMATRIX', 0.0)
            except:
                print("Could not find side_data for this video.")
                self._rotation = 0.0
            self._decoder_thread = Thread(target=self._run_decoder)
            self._decoder_thread.start()
            # wait for the buffer to fill
            sleep(2)
            # initialize the width, height and last frame
            self._init()
            return True
        except Exception as e:
            print(e)
            return False

    def retrieve(self) -> bool:
        if len(self._frame_list) > 0:
            return True
        return False

    def decode(self, videoframe: Optional[av.VideoFrame] = None) -> Optional[np.ndarray]:
        """
        Decode the video frame and return it as a numpy array.
        Args:
            videoframe: av.VideoFrame
                The video frame to decode. If None, pops the first frame from the frame list.
        Returns:
            np.ndarray
            The decoded video frame as a numpy array.
        """
        frame: Optional[av.VideoFrame] = videoframe
        if frame is None:
            frame = self.decode_videoframe()
            if frame is None:
                return None
        frame_ndarray = frame.to_ndarray(format=self.image_format)
        frame_ndarray = self._rotate_frame(frame_ndarray, self.rotation)
        return frame_ndarray

    def decode_videoframe(self) -> Optional[av.VideoFrame]:
        """
        Pops the first frame from the frame list and returns it.
        If the frame list is empty, returns None.
        """

        frame = None
        # pop the first packet and return the frame
        if len(self._frame_list) == 0:
            return None

        if self._undersample_pointer == 0:
            # subtract one to consider last frame is the desired one
            self._undersample_pointer = self._undersample - 1

        while self._undersample_pointer > 0:
            # this lock is necessary to guarantee no other thread is accessing the list
            with self._list_lock:
                if len(self._frame_list) > 0:
                    frame = self._frame_list.popleft()
                    self._actual_frame += 1
                    self._undersample_pointer -= 1
                else:
                    break

        if len(self._frame_list) == 0:
            return None

        if self._undersample_pointer == 0:
            with self._list_lock:
                frame = self._frame_list.popleft()
                self._actual_frame += 1
            return frame
        else:
            return None

    def _init(self) -> None:
        """
        Initialize the width, height and last frame.
        """
        if len(self._frame_list) > 0:
            frame = self._frame_list[0]
            frame_ndarray = frame.to_ndarray(format=self.image_format)
            self._last_frame = frame_ndarray
            self._width = frame_ndarray.shape[1]
            self._height = frame_ndarray.shape[0]

    def read(self) -> Tuple[bool, Optional[np.ndarray]]:
        """
        Read the next frame from the video and return it as a numpy array.
        Returns:
            bool: True if a frame was read, False otherwise.
            np.ndarray: The frame as a numpy array.
        """
        frame = self.decode()
        if isinstance(frame, np.ndarray):
            return True, frame
        return isinstance(frame, np.ndarray), frame

    def read_videoframe(self) -> Tuple[bool, Optional[av.VideoFrame]]:
        """
        Read the next frame from the video and return it as an av.VideoFrame.
        Returns:
            bool: True if a frame was read, False otherwise.
            av.VideoFrame: The frame as an av.VideoFrame.
        """
        frame = self.decode_videoframe()
        return isinstance(frame, av.VideoFrame), frame

    def seek(self, offset_seconds=None, offset_frames=None, backward=True,
             any_frame=False) -> Optional[bool]:
        """Seek to a (key)frame nearest to the given timestamp.
        If backward is True, the frame returned will be the last frame before
        the given timestamp. If backward is False, the frame returned will be
        the first frame after the given timestamp.
        If any_frame is True, Seek to any frame, not just a keyframe.
        @param offset: <int>
        @param backward: <bool>
        @param any_frame: <bool>
        """

        if offset_seconds is None and offset_frames is None:
            raise ValueError(
                "Either offset_seconds or offset_frames must be specified")

        if offset_seconds is not None and offset_frames is not None:
            raise ValueError(
                "Only one of offset_seconds or offset_frames must be specified")

        if self.fps == 0:
            raise ValueError(
                "FPS is zero, cannot seek by frames. Try increasing the buffer size.")

        seek_offset = 0

        if offset_seconds is not None:
            _offset_seconds = offset_seconds
            seek_offset = int(offset_seconds / self.time_base)

        if offset_frames is not None:
            _offset_seconds = offset_frames / self.fps
            seek_offset = int(_offset_seconds / self.time_base)

        if self._container is None:
            return None
        try:
            self._stop = True
            self._decoder_thread.join()
            self._stop = False
            with self._list_lock:
                self._actual_frame = int(_offset_seconds * self.fps)
                self._last_valid_dts = 0
                self._packet_fifo = deque(maxlen=self._packet_fifo_sz)
                self._frame_list = deque(maxlen=self._frame_list_sz)
                self._start_time = 0
                self._eof = False

            self._container.seek(
                seek_offset, backward=backward, any_frame=any_frame,
                stream=self.main_stream)
            self._decoder_thread = Thread(target=self._run_decoder)
            self._decoder_thread.start()
            sleep(0.5)
            self._init()
            return True
        except Exception as e:
            print(e)
            return False
