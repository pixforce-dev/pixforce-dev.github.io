import numpy as np
from typing import Optional, Union, Dict
from .video_capture import VideoCapture
import av
from .codecs import Codecs
from fractions import Fraction


class VideoWriter:
    def __init__(self, file_path: Optional[str],
                 codec: Optional[Codecs],
                 fps: Union[None, int, float, Fraction],
                 width: Optional[int],
                 height: Optional[int],
                 image_format='bgr24',
                 options: Union[None, Dict[str, str]] = None) -> None:
        self._file_path = file_path
        self._codec = codec
        self._fps = fps
        self._width = width
        self._height = height
        # check if above values are None, if so, use default values
        try:
            self._container = av.open(
                self._file_path, "w") if self._file_path else None
        except ValueError as e:
            raise ValueError(
                f"Error opening file. Change file extension and try again: {str(e)}")
        except Exception as e:
            print("Error opening file: ", e)
            raise Exception(f"Error opening file: {str(e)}")
        if self._container:
            self._writing = True
        fps = self._fps
        if type(self._fps) == float:
            fps = Fraction(self._fps).limit_denominator(5)
        if options:
            self._output_stream = self._container.add_stream(
                self._codec.value, rate=fps, options=options) if self._codec else None
        else:
            self._output_stream = self._container.add_stream(
                self._codec.value, rate=fps) if self._codec else None
        if self._output_stream:
            self._output_stream.width = self._width
            self._output_stream.height = self._height
        self._clipping = False
        self.image_format = image_format
        self._container.flush_packets = True

    @property
    def writing(self) -> bool:
        return self._writing

    def write_packet(self, packet) -> None:
        try:
            if self._last_valid_dts >= packet.dts:
                return
            if self._writing:
                self._container.mux(packet)
                self._last_valid_dts = packet.dts
                return
        except Exception as e:
            print("EX Packet dts: ", packet.dts)
            print("Error writing packet: ", e)

    def write(self, frame: np.ndarray) -> bool:
        try:
            if not isinstance(frame, np.ndarray):
                raise TypeError("frame must be a numpy.ndarray")
            frame_ = av.VideoFrame.from_ndarray(
                frame, format=self.image_format)
            packet = self._output_stream.encode(frame_)
            if not packet:
                print("Packet is Empty")
            self._container.mux(packet)
        except Exception as e:
            print("Error writing frame: ", e)
            return False
        return True

    def write_videoframe(self, frame: av.frame.Frame) -> bool:
        try:
            if not isinstance(frame, av.frame.Frame):
                raise TypeError("frame must be a pixi.Frame")
            print("frame_dts: ", frame.dts, " | frame_pts: ", frame.pts)
            packet = self._output_stream.encode(frame)
            self._container.mux(packet)
        except Exception as e:
            print("Error writing frame: ", e)
            return False
        return True

    def start_clip(self, capture: VideoCapture, file_path: str) -> None:
        self._clipping = True
        self._file_path = file_path
        self._capture = capture
        self._container = av.open(self._file_path, "w")
        self._capture._new_packet_callback = None
        self._writing = False
        self._last_valid_dts = 0
        for stream in self._capture._container.streams:
            self._container.add_stream(template=stream)
        if self._writing:
            return
        self._capture._new_packet_callback = self.write_packet
        self._writing = True

    def stop_clip(self) -> None:
        if not self._writing:
            return
        self._capture._new_packet_callback = None
        self.close()

    def close(self) -> None:
        remain_packets = self._output_stream.encode(None)
        self._container.mux(remain_packets)
        if self._container:
            self._container.close()
        self._output_stream = None
        self._container = None
        self._file_path = None
        self._codec = None
        self._fps = None
        self._width = None
        self._height = None
        self._clipping = False
        self._writing = False
